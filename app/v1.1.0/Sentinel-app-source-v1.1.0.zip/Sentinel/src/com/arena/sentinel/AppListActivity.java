package com.arena.sentinel;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Pick an installed app from the phone, extract its APK, and scan it — like MT Manager. */
public class AppListActivity extends Activity {

    private AppAdapter adapter;
    private List<AppInfo> allApps = new ArrayList<>();
    private List<AppInfo> filtered = new ArrayList<>();
    private ProgressBar progress;
    private EditText search;
    private ListView listView;

    static class AppInfo {
        String name, pkg, sourceDir;
        Drawable icon;
    }

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_app_list);

        progress = findViewById(R.id.appListProgress);
        search = findViewById(R.id.appSearch);
        listView = findViewById(R.id.appListView);

        findViewById(R.id.appListBack).setOnClickListener(v -> finish());

        adapter = new AppAdapter();
        listView.setAdapter(adapter);
        listView.setOnItemClickListener((p, v, pos, id) -> confirmScan(filtered.get(pos)));

        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            public void onTextChanged(CharSequence s, int a, int b, int c) { }
            public void afterTextChanged(Editable e) { filter(e.toString()); }
        });

        loadApps();
    }

    private void loadApps() {
        new Thread(() -> {
            PackageManager pm = getPackageManager();
            List<ApplicationInfo> apps = pm.getInstalledApplications(0);
            allApps.clear();
            for (ApplicationInfo ai : apps) {
                AppInfo info = new AppInfo();
                info.name = pm.getApplicationLabel(ai).toString();
                info.pkg = ai.packageName;
                info.sourceDir = ai.sourceDir;
                try { info.icon = pm.getApplicationIcon(ai); } catch (Exception e) { info.icon = null; }
                allApps.add(info);
            }
            Collections.sort(allApps, Comparator.comparing(a -> a.name.toLowerCase()));
            filtered.addAll(allApps);
            runOnUiThread(() -> {
                progress.setVisibility(View.GONE);
                adapter.notifyDataSetChanged();
            });
        }).start();
    }

    private void filter(String q) {
        filtered.clear();
        if (q.isEmpty()) { filtered.addAll(allApps); }
        else {
            String lq = q.toLowerCase();
            for (AppInfo a : allApps)
                if (a.name.toLowerCase().contains(lq) || a.pkg.toLowerCase().contains(lq)) filtered.add(a);
        }
        adapter.notifyDataSetChanged();
    }

    private void confirmScan(AppInfo info) {
        new AlertDialog.Builder(this)
                .setTitle("Scan \"" + info.name + "\"?")
                .setMessage("Package: " + info.pkg)
                .setPositiveButton("Scan", (d, w) -> extractAndScan(info))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void extractAndScan(final AppInfo info) {
        final ProgressDialog pd = new ProgressDialog(this);
        pd.setMessage("Extracting " + info.name + " ...");
        pd.setCancelable(false);
        pd.show();

        new Thread(() -> {
            try {
                File src = new File(info.sourceDir);
                File dest = new File(getCacheDir(), "installed.apk");
                FileInputStream in = new FileInputStream(src);
                FileOutputStream out = new FileOutputStream(dest);
                byte[] buf = new byte[16384]; int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                in.close(); out.close();

                runOnUiThread(() -> pd.setMessage("Opening package ..."));

                File workDir = new File(getCacheDir(), "extract");
                if (workDir.exists()) deleteRecursive(workDir);
                PackageOpener.Opened opened = PackageOpener.open(dest, workDir);
                if (opened.baseApk == null) throw new Exception("Could not open package");

                runOnUiThread(() -> pd.setMessage("AI scanning ..."));

                String key = Prefs.getKey(this);
                String model = Prefs.getModel(this);
                AppAgent.Progress prog = msg -> runOnUiThread(() -> pd.setMessage(msg));
                ScanReport rep = AppAgent.run(key, model, opened, getPackageManager(), prog);
                ReportActivity.LAST = rep;

                deleteRecursive(workDir);
                dest.delete();

                runOnUiThread(() -> {
                    pd.dismiss();
                    startActivity(new Intent(this, ReportActivity.class));
                    finish();
                });
            } catch (Exception e) {
                final String msg = e.getMessage() == null ? e.toString() : e.getMessage();
                runOnUiThread(() -> { pd.dismiss(); Util.toast(this, "Scan failed: " + msg); });
            }
        }).start();
    }

    private boolean deleteRecursive(File f) {
        if (f.isDirectory()) { File[] cs = f.listFiles(); if (cs != null) for (File c : cs) deleteRecursive(c); }
        return f.delete();
    }

    class AppAdapter extends BaseAdapter {
        public int getCount() { return filtered.size(); }
        public Object getItem(int p) { return filtered.get(p); }
        public long getItemId(int p) { return p; }
        public View getView(int p, View conv, ViewGroup parent) {
            if (conv == null)
                conv = LayoutInflater.from(AppListActivity.this).inflate(R.layout.item_app_list, parent, false);
            AppInfo info = filtered.get(p);
            ImageView icon = conv.findViewById(R.id.itemIcon);
            TextView name = conv.findViewById(R.id.itemName);
            TextView pkg = conv.findViewById(R.id.itemPkg);
            if (info.icon != null) icon.setImageDrawable(info.icon);
            else icon.setImageResource(android.R.drawable.sym_def_app_icon);
            name.setText(info.name);
            pkg.setText(info.pkg);
            return conv;
        }
    }
}
